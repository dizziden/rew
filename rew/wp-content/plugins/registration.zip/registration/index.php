<?php 
/*
Plugin Name: Registration
Plugin URI: http://www.orangecreative.net
Description: Plugin for User Registration
Author: C. Lupu
Version: 1.0
Author URI: http://www.orangecreative.net
*/?><?php
global $jal_db_version;
$jal_db_version = "1.0";
global $wpdb;
$table_name = $wpdb->prefix . "registration";
function registration_install() {
   global $wpdb;
   global $jal_db_version;

   $table_name = $wpdb->prefix . "registration";

   $sql = "CREATE TABLE IF NOT EXISTS $table_name (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      fname VARCHAR(255) DEFAULT '' NOT NULL,
	  lname VARCHAR(255) DEFAULT '' NOT NULL,
      username VARCHAR(255) DEFAULT '' NOT NULL,
      email VARCHAR(255) DEFAULT '' NOT NULL,
	  password VARCHAR(255) DEFAULT '' NOT NULL,
	  time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
      UNIQUE KEY id (id)
    ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
   $wpdb->query($sql);
}

register_activation_hook(__FILE__,'registration_install');
function user_registration_actions() {
    add_options_page("Custom Registration", "Custom Registration", 1, "Custom Registration", "registration_setting");
}
 
add_action('admin_menu', 'user_registration_actions');
function registration_setting(){
	$check = get_option('registration_en');
	 global $wpdb;
?>	
 <div class="wrap">
    <?php    echo "<h2>" . __( 'Registration Settings') . "</h2>"; ?>
<form action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>" name="enable_regi" method="post" enctype="multipart/form-data">
 <?php    //echo "<h4>" . __( 'Registration Settings') . "</h4>"; ?>
<label><?php if($check == 1){ ?>
<input type="checkbox" name="check" checked="checked"  value="1"/>Enable / Disable : </label>
<?php }else{ ?>
<input type="checkbox" name="check" value="1"/>Enable / Disable : </label>
<?php } ?>
 <input type="submit" name="update" value="<?php _e('Update') ?>" />
</form>
<?php    echo "<hr>"; ?>
<?php    echo "<h2>" . __( 'All Registered User') . "</h2>"; ?>
<?php 
$querystr = "SELECT * FROM ".$wpdb->prefix."registration";
$myrows = $wpdb->get_results($querystr);
?>
 <table width="70%" border="1">
    <th>Name</th><th>username</th><th>email</th><th>Time</th><th>Remove</th>
    <?php  foreach( $myrows as $row){ ?>
            <tr style="text-align:center;"><td><?php echo $row->fname.' '.$row->lname; ?></td>
                <td><?php echo $row->username; ?></td>
                <td><?php echo $row->email; ?></td>
                <td><?php echo $row->time; ?></td>
                <td><form action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>" name="display" method="post">
                     <input type="submit" name="dele" value="Remove">
                    <input type="hidden" name="id" value="<?php echo $row->id; ?>">
                    </form>
                </td></tr>
    <?php } ?>
</table>    
</div>
<?php
if(isset($_POST['dele'])){
	 global $wpdb;
	$myid = $_POST['id'];
	$query_del = 'DELETE FROM '.$wpdb->prefix.'registration WHERE id = "'.$myid.'"';
	$wpdb->query($query_del);
} ?>
<form action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>" name="display" method="post" enctype="multipart/form-data">
</form> 
<?php 
 }
if(isset($_POST['update'])){
 	if ( isset( $_POST['check'] ) && $_POST['check'] != "") {
		$check1 = $_POST['check'];
	}
 		if(get_option('registration_en') || get_option('registration_en') == ''){
			update_option('registration_en', $check1);
		}
		else {
			add_option('registration_en', $_POST['check']);
		}
 }
function cf_shortcode(){
	global $wpdb;
 	$table_name = $wpdb->prefix . "registration";
 	if(isset($_POST['Submit'])){
 		if ( isset( $_POST['fname'] ) && $_POST['fname'] != "") {
			$fname = strip_tags($_POST['fname']);
		}
		else{
			echo $msg = "Please Fill The First Name";
		}
		if ( isset( $_POST['lname'] ) && $_POST['lname'] != "") {
			$lname = strip_tags($_POST['lname']);
		}
		else{
			echo $msg = "Please Fill The Last Name";
		}
		if ( isset( $_POST['username'] ) && $_POST['username'] != "") {
			$username = strip_tags($_POST['username']);
		}
		else{
			echo $msg = "Username Can not be blank";
		}
		if ( isset( $_POST['email'] ) && $_POST['email'] != "") {
			$email = $_POST['email'];
		}
		else{
			echo $msg = "Please Fill The Emsail";
		}
		if (   isset( $_POST['password'] ) && $_POST['password'] != "") {
			$password = $_POST['password'];
		}
 	$wpdb->insert( 
            $table_name, 
            array( 
                'fname' => $fname,
				'lname' => $lname,
				'username' => $username,
				'email' => $email,
				'password' => md5($password),
				'time' => date('Y-m-d H:i:s')
            )
        );
 	}
 	if(get_option('registration_en') == 1){
	?>
    <div class="wrap">
    <?php   // echo "<h2>" . __( 'Registration Options') . "</h2>"; ?>
     
    <form name="registration_form" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>"><?php    echo "<h4>" . __( 'User Registration') . "</h4>"; ?>
        <input type="hidden" name="oscimp_hidden" value="Y">
       
        <p><?php _e("First Name: " ); ?><input type="text" name="fname" value="<?php //echo $dbhost; ?>" size="20"> </p>
        <p><?php _e("Last Name: " ); ?><input type="text" name="lname" value="<?php //echo $dbname; ?>" size="20"> </p>
        <p><?php _e("Username: " ); ?><input type="text" name="username" value="<?php //echo $dbuser; ?>" size="20"> </p>
        <p><?php _e("Email: " ); ?><input type="text" name="email" value="<?php //echo $dbuser; ?>" size="20"> </p>
        <p><?php _e("Password: " ); ?><input type="password" name="password" value="<?php //echo $dbpwd; ?>" size="20"> </p>
        <hr />
         <p class="submit">
        <input type="submit" name="Submit" value="<?php _e('Submit') ?>" />
        </p>
    </form>
</div>
 <?php   
 	}
	else{
 		echo '<h2>Please Enable Registration From Admin......</h2>';	
	}
}
add_shortcode( 'registration_form', 'cf_shortcode' );
function login_shortcode(){
	?>
 <section class="aa_loginForm">
        <?php 
            global $user_login;
            // In case of a login error.
            if ( isset( $_GET['login'] ) && $_GET['login'] == 'failed' ) : ?>
    	            <div class="aa_error">
    		            <p><?php _e( 'FAILED: Try again!', 'AA' ); ?></p>
    	            </div>
            <?php 
                endif;
            // If user is already logged in.
            if ( is_user_logged_in() ) : ?>
                 <div class="aa_logout"> 
                     <?php 
                        _e( 'Hello', 'AA' ); 
                        echo $user_login; 
                    ?>
                     </br>
                     <?php _e( 'You are already logged in.', 'AA' ); ?>
                 </div>
                 <a id="wp-submit" href="<?php echo wp_logout_url(); ?>" title="Logout">
                    <?php _e( 'Logout', 'AA' ); ?>
                </a>
             <?php 
                 else: 
                     $args = array(
                        'echo'           => true,
                        'redirect'       => home_url( '/wp-admin/' ), 
                        'form_id'        => 'loginform',
                        'label_username' => __( 'Username' ),
                        'label_password' => __( 'Password' ),
                        'label_remember' => __( 'Remember Me' ),
                        'label_log_in'   => __( 'Log In' ),
                        'id_username'    => 'user_login',
                        'id_password'    => 'user_pass',
                        'id_remember'    => 'rememberme',
                        'id_submit'      => 'wp-submit',
                        'remember'       => true,
                        'value_username' => NULL,
                        'value_remember' => true
                    ); 
                     wp_login_form( $args );
                endif;
        ?> 
 	</section>
  <?php  	
}
add_shortcode( 'login_form', 'login_shortcode' );
register_deactivation_hook( __FILE__, 'registration_remove_database' );
function registration_remove_database() {
     global $wpdb;
     $table_name = $wpdb->prefix . 'registration';
     $sql = "DROP TABLE IF EXISTS $table_name";
     $wpdb->query($sql);
     delete_option("registration_en");
}   
?>